var group__group__bsp__bt =
[
    [ "CYBSP_BT_PLATFORM_CFG_SLEEP_MODE_LP_ENABLED", "group__group__bsp__bt.html#ga9090c8f19b0abb9792e62f2649044a7e", null ],
    [ "cybsp_bt_platform_cfg", "group__group__bsp__bt.html#gad2a1cd8a260feac884c816510f34c23e", null ]
];